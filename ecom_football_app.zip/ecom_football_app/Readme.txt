----->
1st open - account.html- login using

user name - admin
password - admin

user name - mani
password - mani

user name - cecil
password - cecil

------>  browse jerseys, stockings , clcik on images of the jersey, will redirect you to main product page

------> check the register page, all validations are completed

------>  cart page, yet to be completed.


