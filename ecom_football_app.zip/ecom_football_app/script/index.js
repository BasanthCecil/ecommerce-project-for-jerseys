let $ = (name) => {
    return document.getElementById(name);
}
let submitform = () => {
    let uname = $('u_name').value;
    let e_address = $('e_address').value;
    let re_e_address = $('re_e_add').value;
    let password = $('password').value;
    let re_password = $('re_password').value;
    let phone = $('phone').value;
    let valid = true;

    if (e_address == re_e_address) {
        alert('Email address not matched');
    }
    if (password == re_password) {
        alert('password not matched');
    }

    if (uname == '') {
        $('u_error').innerHTML = 'Please fill out this form';
        valid = false;
    }
    if (e_address == '') {
        $('e_error').innerHTML = 'Please fill out this form';
        valid = false;
    }
    if (re_e_address == '') {
        $('re_e_error').innerHTML = 'Please fill out this form';
        valid = false;
    }
    if (password == '') {
        $('password_error').innerHTML = 'Please fill out this form';
        valid = false;
    }
    if (re_password == '') {
        $('re_password_error').innerHTML = 'Please fill out this form';
        valid = false;
    }
    if (phone == '') {
        $('phone_error').innerHTML = 'Please fill out this form';
        valid = false;
    }
    if (valid == true) {
        alert('registration successfull!');
    }

}


