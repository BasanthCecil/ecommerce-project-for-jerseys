var MenuItems = document.getElementById("MenuItems");

MenuItems.style.maxHeight = "0px";

function menutoggle() {
	if (MenuItems.style.maxHeight == "0px") {
		MenuItems.style.maxHeight = "200px";
	} else {
		MenuItems.style.maxHeight = "0px";
	}

}


function search() {
	var searc = document.getElementById("search").value;
	if (searc.includes("athletico") && searc.includes("jersey")) {
		window.location.replace("jersey1.html");
	}
	else if (searc.includes("manchester") && searc.includes("jersey")) {
		window.location.replace("jersey2.html");
	}
	else if (searc.includes("psg") && searc.includes("jersey")) {
		window.location.replace("jersey3.html");
	}
	else if (searc.includes("liverpool") && searc.includes("jersey")) {
		window.location.replace("jersey4.html");
	}
	else if (searc.includes("chelsea") && searc.includes("jersey")) {
		window.location.replace("jersey5.html");
	}
	else if (searc.includes("manu") && searc.includes("jersey")) {
		window.location.replace("jersey6.html");
	}
	else if (searc.includes("athletico") && searc.includes("stockings")) {
		window.location.replace("stockings1.html");
	}
	else {
		alert("Not Found");
	}
}





function loginn() {
	var user = document.getElementById("user").value;
	var pass = document.getElementById("pass").value;
	if ((user == "admin" && pass == "admin") || (user == "mani" && pass == "mani") || (user == "cecil" && pass == "cecil")) {

		sessionStorage.setItem("userr", user);

		window.location.replace("index.html");
	}

	else { alert("Invalid credentials"); }
}





function userdetails() {
	var k = sessionStorage.getItem("userr");

	if (k == "admin" && k == "admin") {
		window.location.replace("users/admin.html");
	}
	else if (k == "mani" && k == "mani") {
		window.location.replace("users/mani.html");
	}
	else if (k == "cecil" && k == "cecil") {
		window.location.replace("users/cecil.html");
	}

}



function addtocart() {
	var name = document.getElementById("name").value;
	var price = document.getElementById("price").value;
	var quantity = document.getElementById("quantity").value;
	var size = document.getElementById("size").value;
	alert(name, price, quantity, size);

}



// $(document).ready(function () {

// 	$('#button').click(function (e) {
// 		var data = {
// 			'name': $('#name').text(),
// 			'price': $('#price').text(),
// 		}
// 		console.log(data)
// 		$.post("cart_details.json", data,
// 			function (data, textStatus, jqXHR) {

// 			},
// 			"dataType"
// 		);
// 	});
// })